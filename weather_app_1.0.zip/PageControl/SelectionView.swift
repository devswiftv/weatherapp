//
//  SelectionView.swift
//  PageControl
//
//  Created by Валентина on 02/10/2018.
//  Copyright © 2018 Seemu. All rights reserved.
//

import UIKit

class SelectionView: UIView {

    var condition : Condition = .notselected

}
