UI Page Control Tutorial
==============================

How to make a UI Page Control in Swift.

Tutorial:
http://www.seemuapps.com/page-view-controller-tutorial-with-page-dots

Check out our Website: http://www.seemuapps.com

Follow us on Twtitter: https://twitter.com/SeemuApps

Like us on Facebook: https://www.facebook.com/SeemuApps
